package com.manahil.manager

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.google.zxing.integration.android.IntentIntegrator
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private const val INSPECTION_CHANNEL = "hive_inspections"

data class Hive(
    val id: Long, val code: String, val name: String, val barcode: String,
    val apiary: String, val status: String, val intervalDays: Int,
    val lastInspection: Long, val nextInspection: Long
)
data class Apiary(val id: Long, val name: String, val latitude: Double, val longitude: Double)
data class WeatherInfo(
    val temperature: Double, val wind: Double, val rainProbability: Int,
    val humidity: Int, val description: String, val alerts: List<String>
)

class ApiaryDb(context: Context) : android.database.sqlite.SQLiteOpenHelper(context, "manahil.db", null, 3) {
    override fun onCreate(db: android.database.sqlite.SQLiteDatabase) {
        db.execSQL("""CREATE TABLE hives(
            id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT NOT NULL UNIQUE,
            apiary TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'جيدة',
            notes TEXT NOT NULL DEFAULT '',
            name TEXT NOT NULL DEFAULT '', barcode TEXT NOT NULL DEFAULT '',
            interval_days INTEGER NOT NULL DEFAULT 7,
            last_inspection INTEGER NOT NULL DEFAULT 0,
            next_inspection INTEGER NOT NULL DEFAULT 0)""")
        db.execSQL("""CREATE TABLE inspections(
            id INTEGER PRIMARY KEY AUTOINCREMENT, hive_id INTEGER NOT NULL,
            inspected_at INTEGER NOT NULL, notes TEXT NOT NULL DEFAULT '',
            FOREIGN KEY(hive_id) REFERENCES hives(id))""")
        db.execSQL("""CREATE TABLE apiaries(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            latitude REAL NOT NULL, longitude REAL NOT NULL)""")
    }
    override fun onUpgrade(db: android.database.sqlite.SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) db.execSQL("""CREATE TABLE IF NOT EXISTS apiaries(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            latitude REAL NOT NULL, longitude REAL NOT NULL)""")
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE hives ADD COLUMN name TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE hives ADD COLUMN barcode TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE hives ADD COLUMN interval_days INTEGER NOT NULL DEFAULT 7")
            db.execSQL("ALTER TABLE hives ADD COLUMN last_inspection INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE hives ADD COLUMN next_inspection INTEGER NOT NULL DEFAULT 0")
            db.execSQL("""CREATE TABLE IF NOT EXISTS inspections(
                id INTEGER PRIMARY KEY AUTOINCREMENT, hive_id INTEGER NOT NULL,
                inspected_at INTEGER NOT NULL, notes TEXT NOT NULL DEFAULT '',
                FOREIGN KEY(hive_id) REFERENCES hives(id))""")
        }
    }
    fun allHives(): List<Hive> {
        val out = mutableListOf<Hive>()
        readableDatabase.rawQuery("""SELECT id,code,name,barcode,apiary,status,interval_days,last_inspection,next_inspection
            FROM hives ORDER BY code""", null).use { c ->
            while (c.moveToNext()) out += Hive(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),
                c.getString(4),c.getString(5),c.getInt(6),c.getLong(7),c.getLong(8))
        }
        return out
    }
    fun addHive(code: String, name: String, barcode: String, apiary: String, interval: Int): Long {
        val now = System.currentTimeMillis()
        val next = nextInspectionTime(now, interval)
        return writableDatabase.insertOrThrow("hives", null, ContentValues().apply {
            put("code",code); put("name",name); put("barcode",barcode.ifBlank { code })
            put("apiary",apiary); put("interval_days",interval); put("last_inspection",0L); put("next_inspection",next)
        })
    }
    fun findHiveByBarcode(value: String): Hive? = allHives().firstOrNull {
        it.barcode.equals(value.trim(), true) || it.code.equals(value.trim(), true)
    }
    fun recordInspection(hive: Hive, notes: String) {
        val now = System.currentTimeMillis()
        val next = nextInspectionTime(now, hive.intervalDays)
        writableDatabase.beginTransaction()
        try {
            writableDatabase.insert("inspections", null, ContentValues().apply {
                put("hive_id", hive.id); put("inspected_at", now); put("notes", notes)
            })
            writableDatabase.update("hives", ContentValues().apply {
                put("last_inspection", now); put("next_inspection", next); put("status", "جيدة")
            }, "id=?", arrayOf(hive.id.toString()))
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }
    fun updateStatus(id: Long, status: String) {
        writableDatabase.update("hives", ContentValues().apply { put("status", status) }, "id=?", arrayOf(id.toString()))
    }
    fun allApiaries(): List<Apiary> {
        val out = mutableListOf<Apiary>()
        readableDatabase.rawQuery("SELECT id,name,latitude,longitude FROM apiaries ORDER BY name", null).use { c ->
            while (c.moveToNext()) out += Apiary(c.getLong(0), c.getString(1), c.getDouble(2), c.getDouble(3))
        }
        return out
    }
    fun saveApiary(id: Long?, name: String, lat: Double, lon: Double) {
        val values = ContentValues().apply { put("name", name); put("latitude", lat); put("longitude", lon) }
        if (id == null) writableDatabase.insertOrThrow("apiaries", null, values)
        else writableDatabase.update("apiaries", values, "id=?", arrayOf(id.toString()))
    }
}

private fun nextInspectionTime(from: Long, days: Int): Long {
    val calendar = java.util.Calendar.getInstance().apply {
        timeInMillis = from
        add(java.util.Calendar.DAY_OF_YEAR, days.coerceAtLeast(1))
        set(java.util.Calendar.HOUR_OF_DAY, 9)
        set(java.util.Calendar.MINUTE, 0)
        set(java.util.Calendar.SECOND, 0)
        set(java.util.Calendar.MILLISECOND, 0)
    }
    return calendar.timeInMillis
}

class InspectionReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val id = inputData.getLong("hive_id", -1L)
        val code = inputData.getString("hive_code") ?: "خلية"
        val name = inputData.getString("hive_name") ?: ""
        val interval = inputData.getInt("interval_days", 7)
        createInspectionChannel(applicationContext)
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(applicationContext, INSPECTION_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("موعد فحص الخلية $code")
            .setContentText(if (name.isBlank()) "حان موعد الفحص الدوري لهذه الخلية." else "حان موعد فحص: $name")
            .setStyle(NotificationCompat.BigTextStyle().bigText("حان موعد الفحص الدوري للخلية $code. افتح تطبيق مناحل وسجل نتيجة الفحص."))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true).build()
        if (Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            manager.notify(id.toInt(), notification)
        }
        scheduleInspectionReminder(applicationContext, id, code, name, interval, nextInspectionTime(System.currentTimeMillis(), interval))
        return Result.success()
    }
}

private fun createInspectionChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel(INSPECTION_CHANNEL, "تنبيهات فحص الخلايا", NotificationManager.IMPORTANCE_DEFAULT)
        channel.description = "تذكير بمواعيد الفحص الدوري لكل خلية"
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }
}

private fun scheduleInspectionReminder(context: Context, id: Long, code: String, name: String, interval: Int, at: Long) {
    val data = workDataOf("hive_id" to id, "hive_code" to code, "hive_name" to name, "interval_days" to interval)
    val request = OneTimeWorkRequestBuilder<InspectionReminderWorker>()
        .setInputData(data)
        .setInitialDelay((at - System.currentTimeMillis()).coerceAtLeast(60_000L), TimeUnit.MILLISECONDS)
        .build()
    WorkManager.getInstance(context).enqueueUniqueWork("hive-inspection-$id", ExistingWorkPolicy.REPLACE, request)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createInspectionChannel(this)
        setContent { ManahilApp(ApiaryDb(this)) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManahilApp(db: ApiaryDb) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var hives by remember { mutableStateOf(db.allHives()) }
    var apiaries by remember { mutableStateOf(db.allApiaries()) }
    var search by remember { mutableStateOf("") }
    var showAddHive by remember { mutableStateOf(false) }
    var showAddApiary by remember { mutableStateOf(false) }
    var editingApiary by remember { mutableStateOf<Apiary?>(null) }
    var selectedHive by remember { mutableStateOf<Hive?>(null) }
    var selectedApiary by remember { mutableStateOf<Apiary?>(null) }
    var weather by remember { mutableStateOf<WeatherInfo?>(null) }
    var weatherLoading by remember { mutableStateOf(false) }
    var weatherError by remember { mutableStateOf<String?>(null) }
    var inspectionNotes by remember { mutableStateOf("") }
    var scanMessage by remember { mutableStateOf<String?>(null) }

    fun refresh() { hives = db.allHives(); apiaries = db.allApiaries() }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val scanner = rememberLauncherForActivityResult(ScanContract()) { result ->
        val raw = result.contents
        if (raw != null) {
            val found = db.findHiveByBarcode(raw)
            if (found != null) { selectedHive = found; scanMessage = null }
            else scanMessage = "لم يتم العثور على خلية مرتبطة بهذا الباركود: $raw"
        }
    }

    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        val granted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            try {
                val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                if (loc != null) { editingApiary = (editingApiary ?: Apiary(0,"",loc.latitude,loc.longitude)).copy(latitude=loc.latitude,longitude=loc.longitude); showAddApiary=true }
                else weatherError = "لم يتوفر موقع حديث. فعّل GPS أو أدخل الإحداثيات يدوياً."
            } catch (_: Exception) { weatherError = "تعذر قراءة الموقع. أدخل الإحداثيات يدوياً." }
        } else weatherError = "لم تمنح صلاحية الموقع. يمكنك إدخال الإحداثيات يدوياً."
    }

    fun requestGps() {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (fine || coarse) {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            try {
                val loc = lm.getLastKnownLocation(if (fine) LocationManager.GPS_PROVIDER else LocationManager.NETWORK_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                if (loc != null) { editingApiary = (editingApiary ?: Apiary(0,"",loc.latitude,loc.longitude)).copy(latitude=loc.latitude,longitude=loc.longitude); showAddApiary=true }
                else weatherError = "لم يتوفر موقع محفوظ. شغّل GPS أو أدخل الإحداثيات يدوياً."
            } catch (_: Exception) { weatherError = "تعذر قراءة الموقع. أدخل الإحداثيات يدوياً." }
        } else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    fun loadWeather(apiary: Apiary) {
        weatherLoading=true; weatherError=null; weather=null
        scope.launch {
            try { weather = withContext(Dispatchers.IO) { fetchWeather(apiary.latitude,apiary.longitude) } }
            catch (_: Exception) { weatherError="تعذر جلب الطقس. تحقق من الإنترنت." }
            finally { weatherLoading=false }
        }
    }

    MaterialTheme {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(
                topBar = { TopAppBar(title = { Text("🐝 مناحل") }) },
                floatingActionButton = {
                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallFloatingActionButton(onClick = { val opts = ScanOptions().apply {
                            setDesiredBarcodeFormats(ScanOptions.ALL_CODE_TYPES); setPrompt("وجّه الكاميرا إلى باركود أو QR الخلية")
                            setBeepEnabled(false); setOrientationLocked(true)
                        }; scanner.launch(opts) }) { Text("مسح") }
                        SmallFloatingActionButton(onClick = { editingApiary=null; showAddApiary=true }) { Text("منحل +") }
                        FloatingActionButton(onClick = { showAddHive=true }) { Text("خلية +") }
                    }
                }
            ) { padding ->
                LazyColumn(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item {
                        Text("لوحة المنحل", style=MaterialTheme.typography.headlineMedium)
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            StatCard("الخلايا",hives.size.toString(),Modifier.weight(1f))
                            StatCard("المناحل",apiaries.size.toString(),Modifier.weight(1f))
                            StatCard("مواعيد فحص",hives.count { it.nextInspection <= System.currentTimeMillis() }.toString(),Modifier.weight(1f))
                        }
                        scanMessage?.let { Text(it,color=MaterialTheme.colorScheme.error) }
                    }
                    item { Text("المناحل والطقس",style=MaterialTheme.typography.titleLarge) }
                    items(apiaries,key={ "apiary-${it.id}" }) { a ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                Text(a.name,style=MaterialTheme.typography.titleMedium)
                                Text("خط العرض: ${"%.5f".format(Locale.US,a.latitude)} • خط الطول: ${"%.5f".format(Locale.US,a.longitude)}")
                                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                    Button(onClick={selectedApiary=a;loadWeather(a)}) { Text("الطقس") }
                                    OutlinedButton(onClick={editingApiary=a;showAddApiary=true}) { Text("تعديل الموقع") }
                                }
                                if(selectedApiary?.id==a.id) {
                                    when { weatherLoading -> LinearProgressIndicator(Modifier.fillMaxWidth())
                                        weatherError!=null -> Text(weatherError!!,color=MaterialTheme.colorScheme.error)
                                        weather!=null -> WeatherCard(weather!!) }
                                }
                            }
                        }
                    }
                    item {
                        Text("الخلايا والفحص الدوري",style=MaterialTheme.typography.titleLarge)
                        OutlinedTextField(search,{search=it},Modifier.fillMaxWidth(),label={Text("ابحث بالاسم أو الرقم أو الباركود")},singleLine=true)
                    }
                    items(hives.filter { it.code.contains(search,true)||it.name.contains(search,true)||it.barcode.contains(search,true)||it.apiary.contains(search,true) },key={ "hive-${it.id}" }) { h ->
                        Card(Modifier.fillMaxWidth(),onClick={selectedHive=h}) {
                            Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
                                Text("${h.name.ifBlank { "خلية" }} — ${h.code}",style=MaterialTheme.typography.titleMedium)
                                Text("المنحل: ${h.apiary} • الباركود: ${h.barcode}")
                                Text("الفحص القادم: ${if(h.nextInspection>0) DateFormat.getDateTimeInstance().format(Date(h.nextInspection)) else "غير محدد"}")
                                Text(if(h.nextInspection<=System.currentTimeMillis()) "حان موعد الفحص" else "الفحص الدوري كل ${h.intervalDays} يوم",
                                    color=if(h.nextInspection<=System.currentTimeMillis()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
            if(showAddHive) AddHiveDialog({showAddHive=false}) { code,name,barcode,apiary,days ->
                try {
                    val id=db.addHive(code.trim(),name.trim(),barcode.trim(),apiary.trim(),days)
                    scheduleInspectionReminder(context,id,code.trim(),name.trim(),days,nextInspectionTime(System.currentTimeMillis(),days))
                    refresh(); showAddHive=false
                } catch (_: Exception) { scanMessage="تعذر حفظ الخلية. تأكد من عدم تكرار رقمها." }
            }
            if(showAddApiary) AddApiaryDialog(editingApiary,{showAddApiary=false;editingApiary=null},{requestGps()}) { n,la,lo,id ->
                db.saveApiary(id,n,la,lo);refresh();showAddApiary=false;editingApiary=null
            }
            selectedHive?.let { h ->
                HiveDetailsDialog(h,inspectionNotes,{inspectionNotes=it},{selectedHive=null},{notes ->
                    db.recordInspection(h,notes)
                    scheduleInspectionReminder(context,h.id,h.code,h.name,h.intervalDays,nextInspectionTime(System.currentTimeMillis(),h.intervalDays))
                    inspectionNotes="";refresh();selectedHive=db.allHives().firstOrNull { it.id==h.id }
                }) { status -> db.updateStatus(h.id,status);refresh();selectedHive=db.allHives().firstOrNull { it.id==h.id } }
            }
        }
    }
}

@Composable
fun HiveDetailsDialog(h: Hive, notes: String, onNotes: (String)->Unit, onDismiss: ()->Unit,
                      onInspect: (String)->Unit, onStatus: (String)->Unit) {
    AlertDialog(onDismissRequest=onDismiss,title={Text("${h.name.ifBlank{"خلية"}} — ${h.code}")},
        text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Text("الباركود: ${h.barcode}")
            Text("المنحل: ${h.apiary}")
            Text("الحالة: ${h.status}")
            Text("دورية الفحص: كل ${h.intervalDays} يوم")
            Text("آخر فحص: ${if(h.lastInspection>0) DateFormat.getDateTimeInstance().format(Date(h.lastInspection)) else "لم يسجل بعد"}")
            Text("الفحص القادم: ${DateFormat.getDateTimeInstance().format(Date(h.nextInspection))}")
            OutlinedTextField(notes,onNotes,label={Text("ملاحظات الفحص")},minLines=2)
            Button(onClick={onInspect(notes)},modifier=Modifier.fillMaxWidth()) { Text("تسجيل الفحص اليوم وجدولة القادم") }
            Text("تحديث الحالة:")
            listOf("جيدة","تحتاج فحص","ضعيفة","يتطلب تدخل").forEach { TextButton(onClick={onStatus(it)}) { Text(it) } }
        }},
        confirmButton={TextButton(onClick=onDismiss){Text("إغلاق")}})
}

@Composable
fun AddHiveDialog(onDismiss:()->Unit,onSave:(String,String,String,String,Int)->Unit) {
    var code by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }; var apiary by remember { mutableStateOf("") }
    var days by remember { mutableStateOf("7") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("إضافة خلية")},text={
        Column(verticalArrangement=Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(name,{name=it},label={Text("اسم الخلية")},singleLine=true)
            OutlinedTextField(code,{code=it},label={Text("رقم تعريفي فريد")},singleLine=true)
            OutlinedTextField(barcode,{barcode=it},label={Text("قيمة الباركود (اتركه فارغاً لاستخدام الرقم)")},singleLine=true)
            OutlinedTextField(apiary,{apiary=it},label={Text("اسم المنحل")},singleLine=true)
            OutlinedTextField(days,{days=it},label={Text("الفحص كل كم يوم؟")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
            Text("يمكن طباعة ملصق QR يحمل قيمة الباركود نفسها لكل خلية.",style=MaterialTheme.typography.bodySmall)
        }},
        confirmButton={TextButton(onClick={val d=days.toIntOrNull();if(code.isNotBlank()&&apiary.isNotBlank()&&d!=null&&d in 1..365)onSave(code,name,barcode,apiary,d)} ){Text("حفظ وإعداد التنبيه")}},
        dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}

@Composable
fun AddApiaryDialog(apiary:Apiary?,onDismiss:()->Unit,onGps:()->Unit,onSave:(String,Double,Double,Long?)->Unit) {
    var name by remember(apiary?.id){mutableStateOf(apiary?.name?:"")}
    var lat by remember(apiary?.id){mutableStateOf(apiary?.latitude?.toString()?:"")}
    var lon by remember(apiary?.id){mutableStateOf(apiary?.longitude?.toString()?:"")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("إضافة / تعديل منحل")},text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name,{name=it},label={Text("اسم المنحل")})
            OutlinedTextField(lat,{lat=it},label={Text("خط العرض")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
            OutlinedTextField(lon,{lon=it},label={Text("خط الطول")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
            OutlinedButton(onClick=onGps,modifier=Modifier.fillMaxWidth()){Text("تحديد الموقع الحالي GPS")}
        }},
        confirmButton={TextButton(onClick={val a=lat.toDoubleOrNull();val o=lon.toDoubleOrNull();if(name.isNotBlank()&&a!=null&&o!=null&&a in -90.0..90.0&&o in -180.0..180.0)onSave(name,a,o,apiary?.id)} ){Text("حفظ")}},
        dismissButton={TextButton(onClick=onDismiss){Text("إلغاء")}})
}

@Composable
fun WeatherCard(w:WeatherInfo) {
    Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.secondaryContainer)) {
        Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
            Text("الطقس: ${w.description}",style=MaterialTheme.typography.titleMedium)
            Text("الحرارة ${w.temperature}°م • الرياح ${w.wind} كم/س")
            Text("احتمال المطر ${w.rainProbability}% • الرطوبة ${w.humidity}%")
            Divider();Text("التنبيهات")
            if(w.alerts.isEmpty())Text("لا توجد تنبيهات وفق الحدود الأولية.")
            else w.alerts.forEach{Text("• $it",color=MaterialTheme.colorScheme.error)}
        }
    }
}

suspend fun fetchWeather(lat:Double,lon:Double):WeatherInfo {
    val endpoint="https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code&hourly=precipitation_probability&forecast_days=1&timezone=auto"
    val connection=(URL(endpoint).openConnection() as HttpURLConnection).apply{connectTimeout=12000;readTimeout=12000}
    try {
        val json=JSONObject(connection.inputStream.bufferedReader().use{it.readText()})
        val c=json.getJSONObject("current");val temp=c.getDouble("temperature_2m");val wind=c.getDouble("wind_speed_10m")
        val humidity=c.getInt("relative_humidity_2m");val code=c.getInt("weather_code")
        val hourly=json.getJSONObject("hourly").getJSONArray("precipitation_probability")
        var rain=0;for(i in 0 until minOf(6,hourly.length()))rain=maxOf(rain,hourly.optInt(i,0))
        val desc=when(code){0->"صافٍ";1,2->"غائم جزئياً";3->"غائم";45,48->"ضباب";in 51..67->"رذاذ أو أمطار";in 71..77->"ثلوج";in 80..82->"زخات مطر";in 95..99->"عواصف رعدية";else->"متغير"}
        val alerts=mutableListOf<String>()
        if(temp>=35)alerts+="حرارة مرتفعة: راجع الظل والتهوية والماء."
        if(temp<=5)alerts+="برودة: راجع مخزون الغذاء وحالة الطوائف."
        if(temp<=0)alerts+="احتمال صقيع: تابع التوقعات."
        if(wind>=35)alerts+="رياح قوية: تحقق من ثبات الخلايا."
        if(rain>=70)alerts+="احتمال أمطار مرتفع."
        if(code in 95..99)alerts+="عواصف رعدية متوقعة."
        return WeatherInfo(temp,wind,rain,humidity,desc,alerts)
    } finally { connection.disconnect() }
}

@Composable
fun StatCard(label:String,value:String,modifier:Modifier=Modifier) {
    Card(modifier){Column(Modifier.padding(10.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Text(value,style=MaterialTheme.typography.headlineMedium);Text(label,style=MaterialTheme.typography.labelSmall)
    }}
}
